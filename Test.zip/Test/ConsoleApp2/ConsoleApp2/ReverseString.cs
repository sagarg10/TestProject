﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public class ReverseString
    {
        public static void Revsese()
        {
            string str = Console.ReadLine();
            char[] charsArr = str.ToCharArray();
            int len = str.Length;
            char[] output = new char[len];
            int ind = 0;

            for (int i = len - 1 ; i >= 0; i--)
            {
                output[ind++] = charsArr[i];
            }

        Console.Write(new string(output));
        }

    }
}

﻿using Microsoft.AspNetCore.Mvc;
using WebApi.Domain;
using WebApi.Services;

namespace WebApi.Controllers
{
    public class TestController : Controller
    {
        private readonly IOfferService offerService;

        public TestController(IOfferService offerService) => this.offerService = offerService;

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> GetTodayOffer()
        {
            return (IActionResult)this.offerService.GetTodaysOffers();
        }

        [HttpGet]
        public async Task<IActionResult> GetAllProducts()
        {
            return (IActionResult)this.offerService.GetAllProducts().OrderByDescending(i => i.Price).Take(3);
        }

        [HttpGet]
        public async Task<IActionResult> GetSecondLowest()
        {
            var list = this.offerService.GetAllProducts().OrderBy(i => i.Price).Take(2);
            return (IActionResult)list.OrderByDescending(i => i.Price).Take(1);
        }

        [HttpPost]
        public async Task<IActionResult> AddProduct([FromBody] Product product)
        {
            var list = this.offerService.GetAllProducts().OrderBy(i => i.Price).Take(2);
            return (IActionResult)list.OrderByDescending(i => i.Price).Take(1);
        }


    }
}

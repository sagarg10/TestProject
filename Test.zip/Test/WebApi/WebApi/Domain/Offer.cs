﻿namespace WebApi.Domain
{
    public class Offer
    {

        public string OfferName { get; set; }

        public List<Product> ProductList { get; set; }

        public Offer(string offerName, List<Product> productList)
        {
            OfferName = offerName;
            ProductList = productList;
        }
    }
}

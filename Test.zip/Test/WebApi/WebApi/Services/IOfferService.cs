﻿using WebApi.Domain;

namespace WebApi.Services
{
    public interface IOfferService
    {
        List<Product> GetAllProducts();

        List<Offer> GetTodaysOffers();
    }
}

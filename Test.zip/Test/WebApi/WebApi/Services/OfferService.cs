﻿using WebApi.Domain;

namespace WebApi.Services
{
    public class OfferService : IOfferService
    {

        List<Product> products;
        public OfferService()
        {
            FillProduct();
        }
        private List<Product> FillProduct()
        {
            products = new List<Product>();
            products.Add(new Product("P1", 1000, "P1 desc"));
            products.Add(new Product("P2", 200, "P2 desc"));
            products.Add(new Product("P3", 400, "P3 desc"));
            products.Add(new Product("P4", 700, "P4 desc"));
            products.Add(new Product("P5", 600, "P5 desc"));
            products.Add(new Product("P6", 800, "P6 desc"));

            return products;
        }

        public List<Product> GetAllProducts()
        {
            return products != null ? products : FillProduct();
        }

        public List<Offer> GetTodaysOffers()
        {
            List<Offer> offerList = new List<Offer>();

            offerList.Add(new Offer("ComboPackage1", products.Take(3).ToList());
            offerList.Add(new Offer("ComboPackage2", products.Take(3).ToList());
            offerList.Add(new Offer("ComboPackage3", products.Take(3).ToList());
            offerList.Add(new Offer("ComboPackage4", products.Take(3).ToList());

            return offerList;

        }
    }
}
